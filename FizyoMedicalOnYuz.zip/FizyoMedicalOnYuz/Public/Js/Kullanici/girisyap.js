document.addEventListener('DOMContentLoaded', function() {
    var loginButton = document.getElementById('loginBtn');
    var errorMessage = document.getElementById('loginErrorMessage');

    loginButton.addEventListener('click', function(event) {
        event.preventDefault(); // Sayfanın yeniden yüklenmesini engellemek için form gönderimini durdur

        // Kullanıcı giriş bilgilerini al
        var emailInput = document.querySelector('.input_field input[type="text"]');
        var passwordInput = document.querySelector('.input_field input[type="password"]');
        var email = emailInput.value;
        var password = passwordInput.value;

        // Email formatını kontrol et
        if (!isValidEmail(email)) {
            errorMessage.innerText = 'Lütfen geçerli bir email adresi girin.';
            errorMessage.style.display = 'block';
            return; // Hata durumunda işlemi sonlandır
        }

        // Giriş bilgilerini kontrol et
        if (password.trim() === '') {
            // Şifre boşsa hata mesajını göster
            errorMessage.innerText = 'Lütfen şifrenizi girin.';
            errorMessage.style.display = 'block';
        } else {
            // Giriş başarılıysa teşekkür mesajını göster
            errorMessage.style.display = 'none';
            alert('Giriş başarılı! Hoş geldiniz.');

            // Girilen bilgileri sıfırla
            emailInput.value = '';
            passwordInput.value = '';
        }
    });

    // Email formatını kontrol eden yardımcı fonksiyon
    function isValidEmail(email) {
        return /\S+@\S+\.\S+/.test(email);
    }
});
