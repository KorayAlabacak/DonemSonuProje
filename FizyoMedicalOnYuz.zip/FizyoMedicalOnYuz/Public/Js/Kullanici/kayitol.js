document.addEventListener("DOMContentLoaded", function() {
    const form = document.getElementById("register-form");

    if (form) {
        form.addEventListener("submit", function(event) {
            event.preventDefault();
            
            const name = document.getElementById("name").value;
            const surname = document.getElementById("surname").value;
            const email = document.getElementById("email").value;
            const password = document.getElementById("password").value;

            if (!name || !surname || !email || !password) {
                document.getElementById("error-message").innerText = "Lütfen tüm alanları doldurun.";
                return;
            }

            if (!validateEmail(email)) {
                document.getElementById("error-message").innerText = "Lütfen geçerli bir e-posta adresi girin.";
                return;
            }

            // Kayıt işlemleri burada gerçekleştirilecek

            document.getElementById("error-message").innerText = "";
            document.getElementById("name").value = "";
            document.getElementById("surname").value = "";
            document.getElementById("email").value = "";
            document.getElementById("password").value = "";
            document.getElementById("success-message").innerText = "Başarıyla kayıt oldunuz!";
        });
    }
});

function validateEmail(email) {
    const re = /\S+@\S+\.\S+/;
    return re.test(email);}